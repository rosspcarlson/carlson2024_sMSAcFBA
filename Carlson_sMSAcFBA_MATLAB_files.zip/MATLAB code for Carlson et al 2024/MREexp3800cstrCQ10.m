%MREexp3800cstrCQ10
%December 2022-August 2023
%Ross P. Carlson
%analyzes median experimental chemostat data using surface area constraints
%using temperature corrected TO numbers
%corrects the transporter saturation term for the chemostat conditions
%uses data from NCM3722


%SA:V Volkmer and Heinemann 2011 (3-29%,2%)
%MREmu = [0.391458333;	1.174375;	1.957291667;	2.740208333;	3.523125;	3.914583333;	4.306041667;	4.6975;	5.088958333;	5.871875;	7.04625;	8.22062;	9.78645833;	10.9608333;	-12.13520833]; %non growth parameters for MRE (3-29%)
%MREc = [1.020833333;	3.0625;	5.104166667;	7.145833333;	9.1875;	10.20833333;	11.22916667;	12.25;	13.27083333;	15.3125;	18.375;	21.4375;	25.52083333;	28.58333333;	31.64583333] ; %growth associated parameters for MRE (3-29%)
%SA:V Si et al 2017 (1-15%) MG1655
%MREc = [1.408958333;	2.817916667;	4.226875;	5.635833333;	7.044791667;	8.45375;	9.862708333;	11.27166667;	12.680625;	14.08958333;	15.49854167;	16.9075;	18.31645833;	19.72541667;	21.134375]; %non growth parameters for (1-15%) MRE 
%MREmu = [0.288333333	;0.576666667	;0.865	;1.153333333	;1.441666667	;1.73	;2.018333333	;2.306666667	;2.595	;2.883333333	;3.171666667	;3.46	;3.748333333	;4.036666667;	4.325] ; %growth associated parameters for (1-15%) MRE
%SA:V Si et al 2017 (1-15%) NCM3722
MREc = [1.9370;	3.8741;	5.81125;	7.7483;	9.6854;	11.6225;	13.5595;	15.4966;	17.4337;	19.3708;	21.3079;	23.245;	25.1820;	27.1191;	29.0562;]; %non growth parameters for (1-15%) MRE 
MREmu = [0.5508;	1.1016;	1.6525;	2.2033;	2.7541;	3.305;	3.8558;	4.4066;	4.9575;	5.5083;	6.0591;	6.61;	7.1608;	7.7116;	8.2625] ; %growth associated parameters for (1-15%) MRE

%set for mu = upto 1.2/h
satn = [0.1; 0.19; 0.29; 0.38; 0.48; 0.571;	0.667;	0.714;	0.761;	0.809;	0.857;	0.904;	0.952;	1;	1;	1;	1; 1; 1]; % limiting substrate transporter saturation

%experimental C-limited data sets from literature (Mori et al 2016)(order of columns: growth
%rate, glucose, pyruvate, succinate, lactate out, lactate in, formate,
%acetate out, acetate in)

RM = [ 0.1	1.5	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.2	2.5	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.3	3.54	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.4	4.62	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.5	5.72	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.60	6.8	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.70	8	0.00	0.00	0.00	0.00	0.00	0.25	0.00
0.75	8.77	0.00	0.00	0.00	0.00	0.00	0.80	0.00
0.80	9.35	0.00	0.00	0.00	0.00	0.00	1.4	0.00
0.85	10.4	0.00	0.00	0.00	0.00	0.00	3	0.00
0.90	11.4	0.00	0.00	0.00	0.00	0.00	5	0.00
0.95	12.7	0.00	0.00	0.00	0.00	0.00	7.3	0.00
1.00	14	0.00	0.00	0.00	0.00	0.00	9.3	0.00
1.05	15.43	0.00	0.00	0.00	0.00	0.00	11.78	0.00
1.10	17.06	0.00	0.00	0.00	0.00	0.00	14.34	0.00
1.15	18.86	0.00	0.00	0.00	0.00	0.00	17.06	0.00
1.20	20.86	0.00	0.00	0.00	0.00	0.00	19.93	0.00];

%error in experimental data, assumed at 7% of qace value
RMEr = [0.01	0.11	0	0	0	0.00	0.00	0.00	0.00
0.01	0.18	0	0	0	0.00	0.00	0.00	0.00
0.01	0.25	0	0	0	0.00	0.00	0.00	0.00
0.01	0.32	0	0	0	0.00	0.00	0.00	0.00
0.01	0.40	0	0	0	0.00	0.00	0.00	0.00
0.01	0.48	0.00	0.00	0	0.00	0.00	0.00	0.00
0.01	0.56	0.00	0.00	0	0.00	0.00	0.00	0.00
0.02	0.61	0	0	0	0.00	0.00	0.00	0.00
0.02	0.65	0	0	0	0.00	0.00	0.1	0.00
0.02	0.73	0	0	0	0.00	0.00	0.21	0.00
0.02	0.80	0	0	0	0.00	0.00	0.35	0.00
0.02	0.89	0	0	0	0.00	0.00	0.51	0.00
0.02	0.98	0	0	0	0.00	0.00	0.65	0.00
0.02	1.08	0	0	0	0.00	0.00	0.82	0.00
0.02	1.19	0	0	0	0.00	0.00	1.00	0.00
0.02	1.32	0	0	0	0.00	0.00	1.19	0.00
0.02	1.46	0	0	0	0.00	0.00	1.40	0.00];

totno = 100 ; %100 perturbations
rxnno = 95; %reactions in model

%number of experimental conditions
LR = size(RM,1);
%number of experimental rates considered
LC = size(RM,2);

z = 1 ; %start % of MSA
zmax = 11 ; %highest % of MSA

while z < zmax +1  %cycles through % MSA as set with z and zmax

%output
MREout = zeros(rxnno + 1,totno);
 
loop = 1; 

%temporary RM with perturbations
RMtemp = zeros(LR, LC);

%one hundred perturbations loop
while loop <totno + 1  

%%%%%module for perturbing the experimental values within their limits

x = 1; % row counter
y = 1;  % column counter

while x < LR+1   
    
    y = 1 ;
    while y < LC+1 
        
        %RMtemp(x,y) = RM(x,y) + (randi([-1,1],1,1))*RMEr(x,y)*rand  ;
        RMtemp(x,y) = RM(x,y) +  RMEr(x,y)*(1 + (-1-1).*rand(1,1));   
        y = y +1 ;
         
    end
    
    x = x + 1 ;
    
end

i = 10 ; %experimental growth rate XX change for each cstr dilution rate XX

FBAfunctionMREGLA2700cstrCQ10('Models/EcMREnocostv2.mat', 'ATPm',RMtemp(i,1),RMtemp(i,2),RMtemp(i,3), RMtemp(i,5), RMtemp(i,6), RMtemp(i,7), RMtemp(i,8), RMtemp(i,9),MREc(z), MREmu(z), satn(i));

if isempty(ans)
    MREout(1:rxnno,loop) = 0; %fluxes
    MREout(rxnno+1, loop) = 0; %PO number
     
else
    MREout(1:rxnno,loop) = ans ; %fluxes
    MREout(rxnno+1,loop) = ans(45)/(ans(29) + ans(39) + ans(42) + ans(43) + ans(45) + ans(46) + ans(81)) + (0.5*ans(47))/(ans(47) + ans(48) + ans(49)) + ans(49)/(ans(47) + ans(48) +  ans(49)); %PO
     
end

loop = loop + 1 ;

end

Descr = ['230820EcMRE3800cstrCQ10exp5e', '.xlsx'];    %***
file = Descr; 
rang = 'A2:CV97';                       %*** s+2
coln = 'A1:BF1';                        %*** s+2

if z== 1  
         
        tab = 'MRE1'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE1_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
 end
if z== 2  
         
        tab = 'MRE2'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE2_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
 end

if z== 3  
         
        tab = 'MRE3'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE3_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
 end

 if z== 4  
         
        tab = 'MRE4'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE4_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
 end
   
 if z== 5  
         
        tab = 'MRE5'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE5_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end   
 end
if z== 6  
         
        tab = 'MRE6'; 
        MREout(:,all(MREout ==0)) = [];
       if isempty(MREout)
            'MRE6_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 7  
         
        tab = 'MRE7'; 
        MREout(:,all(MREout ==0)) = [];
      if isempty(MREout)
            'MRE7_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 8  
         
        tab = 'MRE8'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE8_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 9  
         
        tab = 'MRE9'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE9_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 10  
         
        tab = 'MRE10'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE10_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 11  
         
        tab = 'MRE11'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE11_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end     
       if z== 12  
         
        tab = 'MRE12'; 
        MREout(:,all(MREout ==0)) = [];
       if isempty(MREout)
            'MRE12_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end      
     z = z + 1 ;
end   
        
%clear all
