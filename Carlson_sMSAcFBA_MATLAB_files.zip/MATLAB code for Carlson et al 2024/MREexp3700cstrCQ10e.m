%MREexp3700cstrCQ10e
%December 2022-Oct 2023  
%Ross P. Carlson
%analyzes median experimental chemostat data using surface area constraints
%using temperature corrected TO numbers
%corrects the transporter saturation term for the chemostat conditions


%SA:V MG1655 Volkmer and Heinemann 2011 (3-29%,2%)
%MREmu = [0.391458333;	1.174375;	1.957291667;	2.740208333;	3.523125;	3.914583333;	4.306041667;	4.6975;	5.088958333;	5.871875;	7.04625;	8.22062;	9.78645833;	10.9608333;	-12.13520833]; %non growth parameters for MRE (3-29%)
%MREc = [1.020833333;	3.0625;	5.104166667;	7.145833333;	9.1875;	10.20833333;	11.22916667;	12.25;	13.27083333;	15.3125;	18.375;	21.4375;	25.52083333;	28.58333333;	31.64583333] ; %growth associated parameters for MRE (3-29%)
%SA:V MG1655 Si et al 2017 (1-15%)
MREc = [1.408;	2.817;	4.226;	5.635;	7.044;	8.453;	9.862;	11.271;	12.680;	14.089;	15.498;	16.907;	18.316;	19.725;	21.134]; %non growth parameters for (1-15%) MRE 
MREmu = [0.288	;0.576	;0.865	;1.1533	;1.441	;1.73	;2.018	;2.306	;2.595	;2.883	;3.171	;3.46	;3.748	;4.036;	4.325] ; %growth associated parameters for (1-15%) MRE

% limiting substrate transporter saturation
satn = [0.149;	0.298; 0.3477; 0.397;	0.447;	0.485; 0.522; 0.5597;	0.597;	0.634;	0.671;	0.708;	0.746;	0.795;	0.846;	0.895;	0.932;	0.970;	1;	1;	1;	1;	1; 1];
 

%aggregate experimental C-limited data  from literature, (order of columns: growth
%rate, glucose, pyruvate, succinate, lactate out, lactate in, formate,
%acetate out, acetate in)

RM = [ 0.10	1.566	0.000	0.000	0.000	0.000	0.000	0.000	0.000
0.20	2.880	0.000	0.000	0.000	0.000	0.000	0.000	0.000
0.23	3.314	0.000	0.000	0.000	0.000	0.000	0.000	0.000
0.27	3.747	0.000	0.000	0.000	0.000	0.000	0.000	0.000
0.3	4.194	0.000	0.000	0.000	0.000	0.000	0.000	0.000
0.325	4.523	0.000	0.000	0.000	0.000	0.000	0.000	0.000
0.35	4.851	0.000	0.000	0.000	0.000	0.000	0.049	0.000
0.375	5.180	0.000	0.000	0.000	0.000	0.000	0.288	0.000
0.4	5.508	0.000	0.000	0.000	0.000	0.000	0.527	0.000
0.425	5.837	0.000	0.000	0.000	0.000	0.000	0.766	0.000
0.45	6.165	0.000	0.000	0.000	0.000	0.000	1.006	0.000
0.475	6.494	0.000	0.000	0.000	0.000	0.000	1.245	0.000
0.5	6.822	0.000	0.000	0.000	0.000	0.000	1.484	0.000
0.533	7.256	0.000	0.000	0.000	0.000	0.000	1.800	0.000
0.567	7.702	0.000	0.000	0.000	0.000	0.000	2.125	0.000
0.6	8.136	0.000	0.000	0.000	0.000	0.000	2.441	0.000
0.625	8.465	0.000	0.000	0.000	0.000	0.000	2.680	0.000
0.65	8.793	0.000	0.000	0.000	0.000	0.000	2.919	0.000
0.675	9.122	0.000	0.000	0.000	0.000	0.000	3.158	0.000
0.7	9.450	0.000	0.000	0.000	0.000	0.000	3.398	0.000
0.725	9.779	0.000	0.000	0.000	0.000	0.000	3.637	0.000
0.75	10.107	0.000	0.000	0.000	0.000	0.000	3.876	0.000
0.775	10.436	0.000	0.000	0.000	0.000	0.000	4.115	0.000
0.8	10.764	0.000	0.000	0.000	0.000	0.000	4.354	0.000];

%error in experimental data, same order as original rates  
RMEr = [0.01	0.11	0	0	0	0	0	0.00	0
0.01	0.20	0	0	0	0	0	0.00	0
0.01	0.23	0	0	0	0	0	0.00	0
0.01	0.26	0	0	0	0	0	0.00	0
0.02	0.29	0	0	0	0	0	0.00	0
0.02	0.32	0	0	0	0	0	0.00	0
0.02	0.34	0	0	0	0	0	0.00	0
0.02	0.36	0	0	0	0	0	0.00	0
0.02	0.39	0	0	0	0	0	0.04	0
0.02	0.41	0	0	0	0	0	0.05	0
0.02	0.43	0	0	0	0	0	0.07	0
0.02	0.45	0	0	0	0	0	0.09	0
0.02	0.48	0	0	0	0	0	0.10	0
0.02	0.51	0	0	0	0	0	0.13	0
0.02	0.54	0	0	0	0	0	0.15	0
0.02	0.57	0	0	0	0	0	0.17	0
0.02	0.59	0	0	0	0	0	0.19	0
0.02	0.62	0	0	0	0	0	0.20	0
0.02	0.64	0	0	0	0	0	0.22	0
0.02	0.66	0	0	0	0	0	0.24	0
0.02	0.68	0	0	0	0	0	0.25	0
0.02	0.71	0	0	0	0	0	0.27	0
0.02	0.73	0	0	0	0	0	0.29	0
0.02	0.75	0	0	0	0	0	0.30	0];


totno = 100 ; %100 perturbations
rxnno = 95; %reactions in model

%number of experimental conditions
LR = size(RM,1);
%number of experimental rates considered
LC = size(RM,2);

z = 1 ; %start % of MSA 
zmax = 11 ; %highest % of MSA

while z < zmax +1  %cycles through % of MSA as set with z and zmax

%output
MREout = zeros(rxnno + 1,totno);
 
loop = 1; 

%temporary RM with perturbations
RMtemp = zeros(LR, LC);

%one hundred perturbations loop
while loop <totno + 1  

%%%%%module for perturbing the experimental values within their limits

x = 1; % row counter
y = 1;  % column counter

while x < LR+1   
    
    y = 1 ;
    while y < LC+1 
        
        %RMtemp(x,y) = RM(x,y) + (randi([-1,1],1,1))*RMEr(x,y)*rand  ;
        RMtemp(x,y) = RM(x,y) +  RMEr(x,y)*(1 + (-1-1).*rand(1,1));   
        y = y +1 ;
         
    end
    
    x = x + 1 ;
    
end

i = 12 ; %experimental growth rate XX change for each cstr dilution rate XX

FBAfunctionMREGLA2700cstrCQ10('Models/EcMREnocostv2.mat', 'ATPm',RMtemp(i,1),RMtemp(i,2),RMtemp(i,3), RMtemp(i,5), RMtemp(i,6), RMtemp(i,7), RMtemp(i,8), RMtemp(i,9),MREc(z), MREmu(z), satn(i));

if isempty(ans)
    MREout(1:rxnno,loop) = 0; %fluxes
    MREout(rxnno+1, loop) = 0; %PO number
     
else
    MREout(1:rxnno,loop) = ans ; %fluxes
    MREout(rxnno+1,loop) = ans(45)/(ans(29) + ans(39) + ans(42) + ans(43) + ans(45) + ans(46) + ans(81)) + (0.5*ans(47))/(ans(47) + ans(48) + ans(49)) + ans(49)/(ans(47) + ans(48) +  ans(49)); %PO
     
end

loop = loop + 1 ;

end

Descr = ['231011MSA3700e8e', '.xlsx'];    %***
file = Descr; 
rang = 'A2:CV97';                       %*** s+2
coln = 'A1:BF1';                        %*** s+2

if z== 1  
         
        tab = 'MRE1'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE1_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
 end
if z== 2  
         
        tab = 'MRE2'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE2_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
 end

if z== 3  
         
        tab = 'MRE3'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE3_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
 end

 if z== 4  
         
        tab = 'MRE4'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE4_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
 end
   
 if z== 5  
         
        tab = 'MRE5'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE5_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end   
 end
if z== 6  
         
        tab = 'MRE6'; 
        MREout(:,all(MREout ==0)) = [];
       if isempty(MREout)
            'MRE6_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 7  
         
        tab = 'MRE7'; 
        MREout(:,all(MREout ==0)) = [];
      if isempty(MREout)
            'MRE7_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 8  
         
        tab = 'MRE8'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE8_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 9  
         
        tab = 'MRE9'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE9_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 10  
         
        tab = 'MRE10'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE10_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end
if z== 11  
        
        tab = 'MRE11'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MRE11_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end     
       if z== 12  
         
        tab = 'MRE12'; 
        MREout(:,all(MREout ==0)) = [];
       if isempty(MREout)
            'MRE12_empty'
        else
       
        xlswrite(file,MREout,tab,rang);
        end 
end      
     z = z + 1 ;
end   
        
%clear all
