% December 2022 - August 2023
% Ross P. Carlson
% Calculates the Euclidean distance between experimental
% data and the MRE-FBA predictions

%Predictions file: 230510EcMRE_2500

%Sets of glucose batch growth data (G and GA (since A was not
%cometabolized))

EucDistOut = zeros(1,15);
%Beck et al 2022 batch MG1655 data
%EXP = [8.66; 0.67; 2.58]; %G1 batch data
%EXP = [9.1; 0.65; 2.83];  %G2 batch and median data
%EXP = [9.46; 0.67; 2.37]; %G3 batch data
%EXP = [9.16; 0.65; 3.05]; %GA1 batch data
%EXP = [9.68; 0.67; 3.18];  %GA2 batch data
%EXP = [9.29; 0.68; 2.72]; %GA3 batch and median data

%Mori et al 2023 batch NCM3722 data

%EXP = [11.1; 0.94; 3.94]; % batch data 1
EXP = [10.96; 0.92; 6.08]; % batch data 2


UNI = [1;1;1];

%MRE1

MRE1 = [EucD1(1,:);EucD1(3,:); EucD1(4,:)];
nMRE1 = MRE1./EXP ;
Out1 = zeros(size(MRE1,2),1);
i=1;
while i < size(MRE1,2)+1
    Out1(i)= sqrt((nMRE1(1,i)-1).^2 + (nMRE1(2,i)-1).^2 + (nMRE1(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(1) = min(Out1);

%MRE2
MRE2 = [EucD2(1,:);EucD2(3,:); EucD2(4,:)];
nMRE2 = MRE2./EXP ;
Out2 = zeros(size(MRE2,2),1);
i=1;
while i < size(MRE2,2)+1
    Out2(i)= sqrt((nMRE2(1,i)-1).^2 + (nMRE2(2,i)-1).^2 + (nMRE2(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(2) = min(Out2);

%MRE3
MRE3 = [EucD3(1,:);EucD3(3,:); EucD3(4,:)];
nMRE3 = MRE3./EXP ;
Out3 = zeros(size(MRE3,2),1);
i=1;
while i < size(MRE3,2)+1
    Out3(i)= sqrt((nMRE3(1,i)-1).^2 + (nMRE3(2,i)-1).^2 + (nMRE3(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(3) = min(Out3);

%MRE4
MRE4 = [EucD4(1,:);EucD4(3,:); EucD4(4,:)];
nMRE4 = MRE4./EXP ;
Out4 = zeros(size(MRE4,2),1);
i=1;
while i < size(MRE4,2)+1
    Out4(i)= sqrt((nMRE4(1,i)-1).^2 + (nMRE4(2,i)-1).^2 + (nMRE4(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(4) = min(Out4);

%MRE5
MRE5 = [EucD5(1,:);EucD5(3,:); EucD5(4,:)];
nMRE5 = MRE5./EXP ;
Out5 = zeros(size(MRE5,2),1);
i=1;
while i < size(MRE5,2)+1
    Out5(i)= sqrt((nMRE5(1,i)-1).^2 + (nMRE5(2,i)-1).^2 + (nMRE5(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(5) = min(Out5);

%MRE6
MRE6 = [EucD6(1,:);EucD6(3,:); EucD6(4,:)];
nMRE6 = MRE6./EXP ;
Out6 = zeros(size(MRE6,2),1);
i=1;
while i < size(MRE6,2)+1
    Out6(i)= sqrt((nMRE6(1,i)-1).^2 + (nMRE6(2,i)-1).^2 + (nMRE6(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(6) = min(Out6);

%MRE7
MRE7 = [EucD7(1,:);EucD7(3,:); EucD7(4,:)];
nMRE7 = MRE7./EXP ;
Out7 = zeros(size(MRE7,2),1);
i=1;
while i < size(MRE7,2)+1
    Out7(i)= sqrt((nMRE7(1,i)-1).^2 + (nMRE7(2,i)-1).^2 + (nMRE7(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(7) = min(Out7);

%MRE8
MRE8 = [EucD8(1,:);EucD8(3,:); EucD8(4,:)];
nMRE8 = MRE8./EXP ;
Out8 = zeros(size(MRE8,2),1);
i=1;
while i < size(MRE8,2)+1
    Out8(i)= sqrt((nMRE8(1,i)-1).^2 + (nMRE8(2,i)-1).^2 + (nMRE8(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(8) = min(Out8);

%MRE9
MRE9 = [EucD9(1,:);EucD9(3,:); EucD9(4,:)];
nMRE9 = MRE9./EXP ;
Out9 = zeros(size(MRE9,2),1);
i=1;
while i < size(MRE9,2)+1
    Out9(i)= sqrt((nMRE9(1,i)-1).^2 + (nMRE9(2,i)-1).^2 + (nMRE9(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(9) = min(Out9);

%MRE10
MRE10 = [EucD10(1,:);EucD10(3,:); EucD10(4,:)];
nMRE10 = MRE10./EXP ;
Out10 = zeros(size(MRE10,2),1);
i=1;
while i < size(MRE10,2)+1
    Out10(i)= sqrt((nMRE10(1,i)-1).^2 + (nMRE10(2,i)-1).^2 + (nMRE10(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(10) = min(Out10);


 %MRE11
MRE11 = [EucD11(1,:);EucD11(3,:); EucD11(4,:)];
nMRE11 = MRE11./EXP ;
Out11 = zeros(size(MRE11,2),1);
i=1;
while i < size(MRE11,2)+1
    Out11(i)= sqrt((nMRE11(1,i)-1).^2 + (nMRE11(2,i)-1).^2 + (nMRE11(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(11) = min(Out11);

%MRE12
MRE12 = [EucD12(1,:);EucD12(3,:); EucD12(4,:)];
nMRE12 = MRE12./EXP ;
Out12 = zeros(size(MRE12,2),1);
i=1;
while i < size(MRE12,2)+1
    Out12(i)= sqrt((nMRE12(1,i)-1).^2 + (nMRE12(2,i)-1).^2 + (nMRE12(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(12) = min(Out12);

%MRE13
MRE13 = [EucD13(1,:);EucD13(3,:); EucD13(4,:)];
nMRE13 = MRE13./EXP ;
Out13 = zeros(size(MRE13,2),1);
i=1;
while i < size(MRE13,2)+1
    Out13(i)= sqrt((nMRE13(1,i)-1).^2 + (nMRE13(2,i)-1).^2 + (nMRE13(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(13) = min(Out13);

%MRE14
MRE14 = [EucD14(1,:);EucD14(3,:); EucD14(4,:)];
nMRE14 = MRE14./EXP ;
Out14 = zeros(size(MRE14,2),1);
i=1;

while i < size(MRE14,2)+1
    Out14(i)= sqrt((nMRE14(1,i)-1).^2 + (nMRE14(2,i)-1).^2 + (nMRE14(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(14) = min(Out14);

%MRE15
MRE15 = [EucD15(1,:);EucD15(3,:); EucD15(4,:)];
nMRE15 = MRE15./EXP ;
Out15 = zeros(size(MRE15,2),1);
i=1;
while i < size(MRE15,2)+1
    Out15(i)= sqrt((nMRE15(1,i)-1).^2 + (nMRE15(2,i)-1).^2 + (nMRE15(3,i)-1).^2);
   i = i+1 ;
end
EucDistOut(15) = min(Out15);




